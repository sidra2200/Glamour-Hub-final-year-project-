package com.example.glamourhub.admin;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.CursorLoader;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Services;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.AddService;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddNewServiceActivity extends AppCompatActivity {

    EditText EnterTitle;
    ImageView Image;
    Services services;
    ProgressDialog progressDialog;
    Button btn_submit;

    Uri imageUri;
    File file;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_service);
        progressDialog = new ProgressDialog(AddNewServiceActivity.this);
        progressDialog.setMessage("please wait..");
        Image = findViewById(R.id.Image);

        EnterTitle = findViewById(R.id.EnterTitle);
        btn_submit = findViewById(R.id.btn_submit);

        Image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Pick Image"), 1001);
            }
        });

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()) {
                    AddNewService();
                }
            }
        });


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == 1001) {
            Image.setImageURI(data.getData());
            imageUri = data.getData();
        }
    }

    public void AddNewService() {
        progressDialog.show();
        services = new Services();

        if (imageUri == null) {
            Toast.makeText(this, "no image", Toast.LENGTH_SHORT).show();
            progressDialog.dismiss();
        } else {
            file = new File(getRealPathFromURI(imageUri));
            //creating request body for file
            RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
            //creating request body for name
            RequestBody title = RequestBody.create(MediaType.parse("text/plain"), EnterTitle.getText().toString());
            MultipartBody.Part body = MultipartBody.Part.createFormData("filetoupload", file.getName(), requestFile);

            RetrofitClient.getClient().create(AddService.class).AddServices(title, body).enqueue(new Callback<Services>() {
                @Override
                public void onResponse(Call<Services> call, Response<Services> response) {
                    if (response.isSuccessful()) {
                        services = response.body();
                        if (services.getCode() == 200) {
                            Toast.makeText(AddNewServiceActivity.this, services.getMessage(), Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), OurServiceActivity.class));
                            finish();
                        } else {
                            Toast.makeText(AddNewServiceActivity.this, services.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<Services> call, Throwable t) {
                    progressDialog.dismiss();
                    Toast.makeText(AddNewServiceActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

        }
    }

    private String getRealPathFromURI(Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        CursorLoader loader = new CursorLoader(this, contentUri, proj, null, null, null);
        Cursor cursor = loader.loadInBackground();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String result = cursor.getString(column_index);
        cursor.close();
        return result;
    }


    public boolean validation() {
        boolean isvalid = true;
        if (EnterTitle.getText().toString().isEmpty()) {
            EnterTitle.setError("fill this field");
            isvalid = false;
        }
        return isvalid;
    }


}