package com.example.glamourhub;


import static com.example.glamourhub.util.Constants.totalCategories;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.admin.AdminHomeActivity;
import com.example.glamourhub.customer.CustomerHomeActivity;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.LoginService;
import com.example.glamourhub.staffmember.StaffHomeActivity;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.TinyDB;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    EditText edEmail, edPassword;
    Button btn;
    TextView tv, ForgetPasswordTV;
    ProgressDialog progressDialog;
    Users users;
    TinyDB tinyDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        tinyDB = new TinyDB(LoginActivity.this);
        progressDialog = new ProgressDialog(LoginActivity.this);
        progressDialog.setMessage("please wait..");
        edEmail = findViewById(R.id.editTextEmail);
        edPassword = findViewById(R.id.editTextLoginPassword);
        ForgetPasswordTV = findViewById(R.id.ForgetPasswordTV);
        btn = findViewById(R.id.btn_Submit);
        tv = findViewById(R.id.textViewRegister);
        Constants.isAccept = false;
        totalCategories = 0;
        Constants.assignedCategories = 0;

        Dexter.withContext(LoginActivity.this).withPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.POST_NOTIFICATIONS,
                        Manifest.permission.SCHEDULE_EXACT_ALARM)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {

                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {

                    }
                }).check();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()) {
                    checkUserLogin();
                }
            }

        });


        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });

    }

    public void checkUserLogin() {
        progressDialog.show();
        users = new Users();

        RetrofitClient.getClient().create(LoginService.class).Login(
                edEmail.getText().toString(),
                edPassword.getText().toString()
        ).enqueue(new Callback<Users>() {
            @Override
            public void onResponse(Call<Users> call, Response<Users> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    users = response.body();

                    if (users.getCode() == 200) {
                        if (users.getUser_status().equals("A")) {
                            tinyDB.putString("USER_TYPE", users.getUser_type());
                            Toast.makeText(LoginActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                            if (users.getUser_type().equals("A")) {
                                startActivity(new Intent(LoginActivity.this, AdminHomeActivity.class));
                                finish();
                            } else if (users.getUser_type().equals("SM")) {
                                tinyDB.putInt("USER_ID", users.getUser_id());
                                tinyDB.putString("USER_NAME", users.getUser_name());
                                tinyDB.putString("USER_EMAIL", users.getUser_email());
                                tinyDB.putString("USER_CNIC", users.getUser_cnic());
                                tinyDB.putString("USER_CONTACT", users.getUser_contact());
                                tinyDB.putString("USER_SPECIALIZATION", users.getUser_speciality());
                                startActivity(new Intent(LoginActivity.this, StaffHomeActivity.class));
                                finish();
                            } else if (users.getUser_type().equals("C")) {
                                tinyDB.putInt("USER_ID", users.getUser_id());
                                tinyDB.putString("USER_NAME", users.getUser_name());
                                tinyDB.putString("USER_EMAIL", users.getUser_email());
                                tinyDB.putString("USER_CNIC", users.getUser_cnic());
                                tinyDB.putString("USER_CONTACT", users.getUser_contact());
                                startActivity(new Intent(LoginActivity.this, CustomerHomeActivity.class));
                                finish();
                            }
                        } else {
                            Toast.makeText(LoginActivity.this, "Account Blocked By Admin", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        Toast.makeText(LoginActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<Users> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(LoginActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    public boolean validation() {
        boolean isvalid = true;
        if (edEmail.getText().toString().isEmpty()) {
            edEmail.setError("fill this field");
            isvalid = false;
        } else if (edPassword.getText().toString().isEmpty()) {
            edPassword.setError("fill this field");
            isvalid = false;
        }

        return isvalid;
    }


}