package com.example.glamourhub.services;

import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.util.EndPoints;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface CheckAvailabilityService {

    @Headers("Accept:application/json")
    @FormUrlEncoded
    @POST(EndPoints.CHECK_STAFF_MEMBER_AVAILABLE_URL)
    Call<Bookings> checkAvailability(
            @Field("staff_id") int staff_id,
            @Field("booking_date") String booking_date,
            @Field("booking_time") String booking_time
    );


}
