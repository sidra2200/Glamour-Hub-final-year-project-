package com.example.glamourhub.staffmember;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.glamourhub.AboutUsActivity;
import com.example.glamourhub.LoginActivity;
import com.example.glamourhub.R;
import com.example.glamourhub.adapter.BookingAdapter;
import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetStaffBookingService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.example.glamourhub.util.TinyDB;
import com.google.android.material.navigation.NavigationView;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StaffHomeActivity extends AppCompatActivity {

    ImageView logoutIV;
    ListView BookingLV;
    DrawerLayout drawerLayout;
    ImageView drawerMenuIV;
    NavigationView staffNavView;
    ProgressDialog progressDialog;

    List<Bookings> BookingsList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_home);

        progressDialog = new ProgressDialog(StaffHomeActivity.this);
        progressDialog.setMessage("please wait..");

        logoutIV = findViewById(R.id.logoutIV);
        BookingLV = findViewById(R.id.BookingLV);
        drawerLayout = findViewById(R.id.drawerLayout);
        drawerMenuIV = findViewById(R.id.drawerMenuIV);
        staffNavView = findViewById(R.id.staffNavView);


        drawerMenuIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        logoutIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TinyDB(StaffHomeActivity.this).clear();
                startActivity(new Intent(StaffHomeActivity.this, LoginActivity.class));
                finishAffinity();
            }
        });


        staffNavView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.notifyNav) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                    startActivity(new Intent(StaffHomeActivity.this, SMNotificationActivity.class));
                } else if (item.getItemId() == R.id.myBookingsNav) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                    startActivity(new Intent(StaffHomeActivity.this, StaffMemberMyBookingActivity.class));
                } else if (item.getItemId() == R.id.aboutNav) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                    startActivity(new Intent(StaffHomeActivity.this, AboutUsActivity.class));
                } else if (item.getItemId() == R.id.profileNav) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                    startActivity(new Intent(StaffHomeActivity.this, SMProfileActivity.class));
                }
                return true;
            }
        });

        getBookingData();

    }

    private void getBookingData() {
        progressDialog.show();
        BookingsList.clear();

        RetrofitClient.getClient().create(GetStaffBookingService.class).getbookings().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (new TinyDB(StaffHomeActivity.this).getInt("USER_ID") == data.getInt("fk_staff_id")
                                        && data.getString("booking_status").equals("A")) {
                                    BookingsList.add(new Bookings(
                                            data.getInt("booking_id"),
                                            data.getString("booking_date"),
                                            data.getString("booking_time"),
                                            data.getInt("fk_user_id"),
                                            data.getString("booking_status"),
                                            data.getInt("booking_total_price")
                                    ));
                                }

                            }

                            BookingAdapter adapter = new BookingAdapter(BookingsList,
                                    StaffHomeActivity.this, new OnItemClick() {
                                @Override
                                public void onClick(int pos) {
                                    Constants.bookings = BookingsList.get(pos);
                                    startActivity(new Intent(getApplicationContext(), StaffBookingDetailActivity.class));
                                }
                            });
                            BookingLV.setAdapter(adapter);


                        } catch (Exception exception) {
                            Toast.makeText(StaffHomeActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(StaffHomeActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(StaffHomeActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }
}