package com.example.glamourhub.staffmember;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.adapter.BookingAdapter;
import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetStaffBookingService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.example.glamourhub.util.TinyDB;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StaffMemberMyBookingActivity extends AppCompatActivity {

    ListView BookingLV;
    Spinner staffStatus;

    String[] status = {"Active", "Completed"};

    ProgressDialog progressDialog;
    List<Bookings> BookingsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_staff_member_my_booking);
        staffStatus = findViewById(R.id.staffStatus);

        BookingLV = findViewById(R.id.BookingLV);

        progressDialog = new ProgressDialog(StaffMemberMyBookingActivity.this);
        progressDialog.setMessage("please wait..");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(StaffMemberMyBookingActivity.this,
                android.R.layout.simple_spinner_dropdown_item, status);
        staffStatus.setAdapter(adapter);

        staffStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    getBookingData("A");
                } else if (position == 1) {
                    getBookingData("CMP");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

    private void getBookingData(String status) {
        progressDialog.show();
        BookingsList.clear();

        RetrofitClient.getClient().create(GetStaffBookingService.class).getbookings().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);

                                if (new TinyDB(StaffMemberMyBookingActivity.this).getInt("USER_ID") == data.getInt("fk_staff_id")
                                        && data.getString("booking_status").equals(status)) {
                                    BookingsList.add(new Bookings(
                                            data.getInt("booking_id"),
                                            data.getString("booking_date"),
                                            data.getString("booking_time"),
                                            data.getInt("fk_user_id"),
                                            data.getString("booking_status"),
                                            data.getInt("booking_total_price")
                                    ));
                                }


                            }

                            BookingAdapter adapter = new BookingAdapter(BookingsList,
                                    StaffMemberMyBookingActivity.this, new OnItemClick() {
                                @Override
                                public void onClick(int pos) {
                                    Constants.bookings = BookingsList.get(pos);
                                    startActivity(new Intent(getApplicationContext(), StaffBookingDetailActivity.class));
                                }
                            });
                            BookingLV.setAdapter(adapter);


                        } catch (Exception exception) {
                            Toast.makeText(StaffMemberMyBookingActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(StaffMemberMyBookingActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(StaffMemberMyBookingActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), StaffHomeActivity.class));
        finishAffinity();
    }
}