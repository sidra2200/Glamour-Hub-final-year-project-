package com.example.glamourhub.services;

import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.util.EndPoints;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface UpdateSubService {
    @Headers("Accept: application/json")
    @FormUrlEncoded
    @POST(EndPoints.Update_Sub_Service_URL)
    Call<Subservices> Updatesubservices(
            @Field("ss_id") int ss_id,
            @Field("ss_title") String ss_title,
            @Field("ss_description") String ss_description,
            @Field("ss_price") int ss_price,
            @Field("ss_duration") String ss_duration
    );
}
