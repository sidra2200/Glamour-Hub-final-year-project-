package com.example.glamourhub.customer;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.adapter.BookingAdapter;
import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetBookingService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.example.glamourhub.util.TinyDB;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BookingHistoryActivity extends AppCompatActivity {
    ListView BookingLV;
    Spinner bookingSpinner;
    String[] BookingStatus = {"Pending", "Active", "Rejected", "Cancelled", "Completed"};
    ProgressDialog progressDialog;
    TinyDB tinyDB;
    List<Bookings> BookingsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_history);
        progressDialog = new ProgressDialog(BookingHistoryActivity.this);
        progressDialog.setMessage("please wait..");
        BookingLV = findViewById(R.id.BookingLV);
        tinyDB = new TinyDB(BookingHistoryActivity.this);
        bookingSpinner = findViewById(R.id.bookingSpinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(BookingHistoryActivity.this,
                android.R.layout.simple_spinner_dropdown_item, BookingStatus);
        bookingSpinner.setAdapter(adapter);
        bookingSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    getBookings("P");
                } else if (position == 1) {
                    getBookings("A");
                } else if (position == 2) {
                    getBookings("R");
                } else if (position == 3) {
                    getBookings("C");
                } else if (position == 4) {
                    getBookings("CMP");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

    private void getBookings(String status) {
        progressDialog.show();
        BookingsList.clear();

        RetrofitClient.getClient().create(GetBookingService.class).getbookings().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (data.getString("booking_status").equals(status)) {
                                    if (data.getInt("fk_user_id") == tinyDB.getInt("USER_ID")) {
                                        BookingsList.add(new Bookings(
                                                data.getInt("booking_id"),
                                                data.getString("booking_date"),
                                                data.getString("booking_time"),
                                                data.getInt("fk_user_id"),
                                                data.getString("booking_status"),
                                                data.getInt("booking_total_price")
                                        ));
                                    }
                                }
                            }

                            BookingAdapter adapter = new BookingAdapter(BookingsList,
                                    BookingHistoryActivity.this, new OnItemClick() {
                                @Override
                                public void onClick(int pos) {
                                    Constants.bookings = BookingsList.get(pos);
                                    startActivity(new Intent(getApplicationContext(), BookingHistoryDetailActivity.class));
                                }
                            });
                            BookingLV.setAdapter(adapter);


                        } catch (Exception exception) {
                            Toast.makeText(BookingHistoryActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(BookingHistoryActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(BookingHistoryActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }

}