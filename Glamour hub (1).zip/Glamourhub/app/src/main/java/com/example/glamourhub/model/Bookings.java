package com.example.glamourhub.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Bookings {

    @SerializedName("booking_id")
    @Expose
    private int booking_id;

    @SerializedName("booking_date")
    @Expose
    private String booking_date;
    @SerializedName("booking_time")
    @Expose
    private String booking_time;
    @SerializedName("fk_user_id")
    @Expose
    private int fk_user_id;
    @SerializedName("booking_status")
    @Expose
    private String booking_status;

    @SerializedName("booking_total_price")
    @Expose
    private int booking_total_price;

    @SerializedName("code")
    @Expose
    private int code;

    @SerializedName("error")
    @Expose
    private boolean error;

    @SerializedName("message")
    @Expose
    private String message;

    public Bookings() {
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(int booking_id) {
        this.booking_id = booking_id;
    }

    public String getBooking_date() {
        return booking_date;
    }

    public void setBooking_date(String booking_date) {
        this.booking_date = booking_date;
    }

    public String getBooking_time() {
        return booking_time;
    }

    public void setBooking_time(String booking_time) {
        this.booking_time = booking_time;
    }

    public int getFk_user_id() {
        return fk_user_id;
    }

    public void setFk_user_id(int fk_user_id) {
        this.fk_user_id = fk_user_id;
    }

    public String getBooking_status() {
        return booking_status;
    }

    public void setBooking_status(String booking_status) {
        this.booking_status = booking_status;
    }

    public int getBooking_total_price() {
        return booking_total_price;
    }

    public void setBooking_total_price(int booking_total_price) {
        this.booking_total_price = booking_total_price;
    }


    public Bookings(int booking_id, String booking_date, String booking_time, int fk_user_id, String booking_status, int booking_total_price) {
        this.booking_id = booking_id;
        this.booking_date = booking_date;
        this.booking_time = booking_time;
        this.fk_user_id = fk_user_id;
        this.booking_status = booking_status;
        this.booking_total_price = booking_total_price;
    }
}
