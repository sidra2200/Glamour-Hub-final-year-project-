package com.example.glamourhub.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.glamourhub.R;
import com.example.glamourhub.model.Services;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.util.EndPoints;
import com.example.glamourhub.util.OnItemClick;

import java.util.List;

public class ServiceAdapter extends BaseAdapter {

    List<Services> servicesList;
    Context context;
    OnItemClick onItemClick;
    LayoutInflater inflater;

    public ServiceAdapter(List<Services> servicesList, Context context, OnItemClick onItemClick) {
        this.context = context;
        this.servicesList = servicesList;
        this.onItemClick = onItemClick;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return servicesList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.item_service, parent, false);

        TextView serviceName = convertView.findViewById(R.id.serviceName);
        ImageView serviceIV = convertView.findViewById(R.id.serviceIV);

        serviceName.setText(servicesList.get(position).getService_title());

        Glide.with(context).load(EndPoints.IMAGE_URL + servicesList.get(position).getService_image())
                .into(serviceIV);

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.onClick(position);

            }
        });


        return convertView;
    }
}
