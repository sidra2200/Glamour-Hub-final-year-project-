package com.example.glamourhub.services;

import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.util.EndPoints;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface InsertBookingService {
    @Headers("Accept: application/json")
    @FormUrlEncoded
    @POST(EndPoints.Insert_Booking_URL)
    Call<Bookings> InsertBooking(
            @Field("booking_date") String booking_date,
            @Field("booking_time") String booking_time,
            @Field("fk_user_id") int fk_user_id,
            @Field("booking_total_price") int booking_total_price
    );


}
