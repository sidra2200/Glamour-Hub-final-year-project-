package com.example.glamourhub.staffmember;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetBookingServices;
import com.example.glamourhub.services.GetStaffBookingService;
import com.example.glamourhub.services.UpdateProfileService;
import com.example.glamourhub.util.TinyDB;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SMProfileActivity extends AppCompatActivity {

    EditText ETName, ETEmail, ETContact, EtCnic;
    Button changePassword, update;
    TextView ETSpeciality, ETFees;
    ProgressDialog progressDialog;
    TinyDB tinyDB;
    int totalAmount = 0;
    Users usersData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smprofile);
        progressDialog = new ProgressDialog(SMProfileActivity.this);
        progressDialog.setMessage("please wait..");
        tinyDB = new TinyDB(SMProfileActivity.this);
        ETName = findViewById(R.id.ETName);
        ETEmail = findViewById(R.id.ETEmail);
        ETContact = findViewById(R.id.ETContact);
        EtCnic = findViewById(R.id.EtCnic);
        ETSpeciality = findViewById(R.id.ETSpeciality);
        ETFees = findViewById(R.id.ETFees);

        ETName.setText(tinyDB.getString("USER_NAME"));
        ETEmail.setText(tinyDB.getString("USER_EMAIL"));
        ETContact.setText(tinyDB.getString("USER_CONTACT"));
        EtCnic.setText(tinyDB.getString("USER_CNIC"));
        ETSpeciality.setText(tinyDB.getString("USER_SPECIALIZATION"));

        calculatePercentageAndShow();

        update = findViewById(R.id.update);
        changePassword = findViewById(R.id.changePassword);
        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SMProfileActivity.this, ChangePasswordActivity.class));
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()) {
                    UpdateProfile();
                }
            }
        });
    }

    private void calculatePercentageAndShow() {
        progressDialog.show();
        RetrofitClient.getClient().create(GetStaffBookingService.class).getbookings().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (new TinyDB(SMProfileActivity.this).getInt("USER_ID") == data.getInt("fk_staff_id")
                                        && data.getString("booking_status").equals("CMP")) {
                                    getBookingDetail(data.getInt("booking_id"));
                                }
                            }
                            progressDialog.dismiss();

                        } catch (Exception exception) {
                            Toast.makeText(SMProfileActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(SMProfileActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(SMProfileActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void getBookingDetail(int bookingId) {
        RetrofitClient.getClient().create(GetBookingServices.class).getServices().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    if (response.code() == 200) {
                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (data.getInt("fk_booking_id") == bookingId) {
                                    totalAmount = totalAmount + calculateAmount(data.getInt("ss_price"));
//                                    subServicesList.add(new Subservices(
//                                            data.getInt("bd_id"),
//                                            data.getInt("fk_booking_id"),
//                                            data.getInt("fk_subservice_id"),
//                                            data.getInt("fk_staff_id"),
//                                            data.getInt("ss_id"),
//                                            data.getString("ss_title"),
//                                            data.getString("ss_image"),
//                                            data.getInt("ss_price"),
//                                            data.getInt("service_id"),
//                                            data.getString("service_title")
//                                    ));

                                }

                            }

                            ETFees.setText("Rs." + totalAmount);

                        } catch (Exception exception) {
                            Toast.makeText(SMProfileActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(SMProfileActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(SMProfileActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }

    public void UpdateProfile() {
        progressDialog.show();
        usersData = new Users();
        RetrofitClient.getClient().create(UpdateProfileService.class).UpdateProfile(
                tinyDB.getInt("USER_ID"),
                ETName.getText().toString(),
                EtCnic.getText().toString(),
                ETContact.getText().toString(),
                ETEmail.getText().toString()

        ).enqueue(new Callback<Users>() {
            @Override
            public void onResponse(Call<Users> call, Response<Users> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    usersData = response.body();
                    if (usersData.getCode() == 200) {
                        tinyDB.putString("USER_NAME", ETName.getText().toString());
                        tinyDB.putString("USER_CONTACT", ETContact.getText().toString());
                        tinyDB.putString("USER_CNIC", EtCnic.getText().toString());
                        Toast.makeText(SMProfileActivity.this, usersData.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), StaffHomeActivity.class));
                        finish();
                    } else {
                        Toast.makeText(SMProfileActivity.this, usersData.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Users> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(SMProfileActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public boolean validation() {
        boolean isvalid = true;
        if (ETName.getText().toString().isEmpty()) {
            ETName.setError("fill this field");
            isvalid = false;
        }
        if (ETEmail.getText().toString().isEmpty()) {
            ETEmail.setError("fill this field");
            isvalid = false;
        }
        if (ETContact.getText().toString().isEmpty()) {
            ETContact.setError("fill this field");
            isvalid = false;
        }
        if (EtCnic.getText().toString().isEmpty()) {
            EtCnic.setError("fill this field");
            isvalid = false;
        }
        return isvalid;
    }


    public int calculateAmount(int totalAmount) {
        int percentage = 30;
        int advanceAmount = Math.round(totalAmount * percentage / 100.0f);
        return totalAmount - advanceAmount;
    }

}