package com.example.glamourhub.customer;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.adapter.NotificationAdapter;
import com.example.glamourhub.model.Notification;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetNotificationService;
import com.example.glamourhub.util.OnItemClick;
import com.example.glamourhub.util.TinyDB;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificationActivity extends AppCompatActivity {

    ListView NotificationLV;

    ProgressDialog progressDialog;
    List<Notification> notificationList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification2);

        progressDialog = new ProgressDialog(NotificationActivity.this);
        progressDialog.setMessage("please wait..");
        NotificationLV = findViewById(R.id.NotificationLV);
        getNotifications();

    }


    private void getNotifications() {
        progressDialog.show();
        notificationList.clear();
        RetrofitClient.getClient().create(GetNotificationService.class).getNotification().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {
                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);

                                if (data.getString("n_for").equals("C")
                                        && data.getInt("n_for_id") == new TinyDB(NotificationActivity.this).getInt("USER_ID"))
                                    notificationList.add(new Notification(
                                            data.getInt("n_id"),
                                            data.getString("n_title"),
                                            data.getString("n_for"),
                                            data.getInt("n_for_id"),
                                            data.getString("n_type"),
                                            data.getInt("n_typeid"),
                                            data.getString("n_createdDateTime")
                                    ));

                            }

                            NotificationAdapter adapter = new NotificationAdapter(notificationList,
                                    NotificationActivity.this, new OnItemClick() {
                                @Override
                                public void onClick(int pos) {
                                    startActivity(new Intent(getApplicationContext(), BookingHistoryActivity.class));
                                }
                            });
                            NotificationLV.setAdapter(adapter);


                        } catch (Exception exception) {
                            Toast.makeText(NotificationActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(NotificationActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(NotificationActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }

}