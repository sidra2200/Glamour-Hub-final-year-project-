package com.example.glamourhub.admin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.glamourhub.R;
import com.example.glamourhub.adapter.FeedbackAdapter;
import com.example.glamourhub.adapter.SubServiceAdapter;
import com.example.glamourhub.model.Feedback;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetFeedbackService;
import com.example.glamourhub.services.GetSubService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminFeedbackActivity extends AppCompatActivity {
    ListView FeedbackLV;
    ProgressDialog progressDialog;
    List<Feedback> feedbackList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_admin_feedback);
        progressDialog = new ProgressDialog(AdminFeedbackActivity.this);
        progressDialog.setMessage("please wait..");
        FeedbackLV = findViewById(R.id.FeedbackLV);

        getFeedback();

    }
    private void getFeedback() {
        progressDialog.show();
        feedbackList.clear();

        RetrofitClient.getClient().create(GetFeedbackService.class).getFeedback().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);

                                    feedbackList.add(new Feedback(

                                            data.getString("feedback_title"),
                                            data.getInt("user_id"),
                                            data.getString("rating"),
                                            data.getString("user_name")

                                    ));



                            }

                            FeedbackAdapter adapter = new FeedbackAdapter(feedbackList,
                                    AdminFeedbackActivity.this, new OnItemClick() {
                                @Override
                                public void onClick(int pos) {
//                                    Constants.feedback = feedbackList.get(pos);
                                   /* startActivity(new Intent(getApplicationContext(), ProductDetailActivity.class));
                                    finish();*/

                                }
                            });
                            FeedbackLV.setAdapter(adapter);


                        } catch (Exception exception) {
                            Toast.makeText(AdminFeedbackActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(AdminFeedbackActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(AdminFeedbackActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }

}