package com.example.glamourhub.admin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.adapter.ServiceAdapter;
import com.example.glamourhub.model.Services;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetServices;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OurServiceActivity extends AppCompatActivity {

    Button btn_AddService;
    GridView OurServicesLV;
    ProgressDialog progressDialog;
    List<Services> servicesList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_our_service);
        progressDialog = new ProgressDialog(OurServiceActivity.this);
        progressDialog.setMessage("please wait..");
        btn_AddService = findViewById(R.id.btn_AddService);
        OurServicesLV = findViewById(R.id.OurServicesLV);
        btn_AddService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(OurServiceActivity.this, AddNewServiceActivity.class));
            }
        });

        getServiceData();

    }

    private void getServiceData() {
        progressDialog.show();
        servicesList.clear();
        RetrofitClient.getClient().create(GetServices.class).getservices().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {
                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);

                                servicesList.add(new Services(
                                        data.getInt("service_id"),
                                        data.getString("service_title"),
                                        data.getString("service_image"),
                                        data.getString("service_status")
                                ));

                            }

                            ServiceAdapter adapter = new ServiceAdapter(servicesList,
                                    OurServiceActivity.this, new OnItemClick() {
                                @Override
                                public void onClick(int pos) {
                                    Constants.services = servicesList.get(pos);
                                    startActivity(new Intent(getApplicationContext(), ServiceDetailActivity.class));

                                }
                            });
                            OurServicesLV.setAdapter(adapter);


                        } catch (Exception exception) {
                            Toast.makeText(OurServiceActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(OurServiceActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(OurServiceActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }

}