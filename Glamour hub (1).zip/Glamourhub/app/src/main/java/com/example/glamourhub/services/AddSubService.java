package com.example.glamourhub.services;

import com.example.glamourhub.model.Services;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.util.EndPoints;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface AddSubService {

    @Headers("Accept:application/json")
    @Multipart
    @POST(EndPoints.Add_Sub_Service_URL)
    Call<Subservices> AddSubServices(
            @Part("ss_title") RequestBody ss_title,
            @Part("ss_description") RequestBody ss_description,
            @Part("ss_price") RequestBody ss_price,
            @Part("ss_duration") RequestBody ss_duration,
            @Part MultipartBody.Part filetoupload,
            @Part("fk_service_id") RequestBody fk_service_id
            );


}
