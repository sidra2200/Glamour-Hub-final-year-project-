package com.example.glamourhub.admin;

import static com.example.glamourhub.util.Constants.totalCategories;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.glamourhub.LoginActivity;
import com.example.glamourhub.R;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.TinyDB;

public class AdminHomeActivity extends AppCompatActivity {

    ImageView logoutIV;
    CardView notificationCV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
        notificationCV = findViewById(R.id.notificationCV);
        notificationCV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AdminHomeActivity.this, NotificationActivity.class));
            }
        });
        logoutIV = findViewById(R.id.logoutIV);
        logoutIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TinyDB(AdminHomeActivity.this).clear();
                startActivity(new Intent(AdminHomeActivity.this, LoginActivity.class));
                finishAffinity();
            }
        });

        CardView OurServices = findViewById(R.id.OurServices);
        OurServices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(AdminHomeActivity.this, OurServiceActivity.class));
            }
        });


        CardView MyBookings = findViewById(R.id.MyBookings);
        MyBookings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Constants.isAccept = false;
                totalCategories = 0;
                Constants.assignedCategories = 0;
                startActivity(new Intent(AdminHomeActivity.this, MyBookingActivity.class));
            }
        });

        CardView MyStaff = findViewById(R.id.MyStaff);
        MyStaff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(AdminHomeActivity.this, MyStaffActivity.class));
            }
        });
        CardView Feedback = findViewById(R.id.Feedback);
        Feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(AdminHomeActivity.this, AdminFeedbackActivity.class));
            }
        });


    }
}