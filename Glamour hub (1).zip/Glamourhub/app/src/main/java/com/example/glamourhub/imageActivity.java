package com.example.glamourhub;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.github.dhaval2404.imagepicker.ImagePicker;


public class imageActivity extends AppCompatActivity {
    TextView captureTxt;
    String path;
    Uri uri;
    private ImageView captureImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);
        captureTxt = findViewById(R.id.idEventBrowse);
        captureImage = findViewById(R.id.my_avatar);
        captureTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              ImagePicker.Companion.with(imageActivity.this)
                        .crop()
                        .maxResultSize(1080, 1080)
                        .start(101);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101 && resultCode == Activity.RESULT_OK) {
            Uri uri = data.getData();
            captureImage.setImageURI(uri);
        } else {
            Toast.makeText(getApplicationContext(), "No Image Selected", Toast.LENGTH_SHORT).show();
        }
    }

}
