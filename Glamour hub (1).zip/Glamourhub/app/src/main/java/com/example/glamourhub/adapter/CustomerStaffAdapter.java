package com.example.glamourhub.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Users;

import java.util.List;

public class CustomerStaffAdapter extends RecyclerView.Adapter<CustomerStaffAdapter.ViewHolder> {

    private List<Users> itemList;
    private Context context;

    public CustomerStaffAdapter(Context context, List<Users> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        TextView speciality1;

        public ViewHolder(View view) {
            super(view);
            speciality1 = view.findViewById(R.id.speciality1);
            textView = view.findViewById(R.id.name1);
        }
    }

    @Override
    public CustomerStaffAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_customer_staff, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CustomerStaffAdapter.ViewHolder holder, int position) {
        Users item = itemList.get(position);
        holder.textView.setText(item.getUser_name());
        holder.speciality1.setText(item.getUser_speciality());
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }
}
