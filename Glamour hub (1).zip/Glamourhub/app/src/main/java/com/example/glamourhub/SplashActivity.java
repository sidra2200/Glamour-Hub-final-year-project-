package com.example.glamourhub;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.admin.AdminHomeActivity;
import com.example.glamourhub.customer.CustomerHomeActivity;
import com.example.glamourhub.staffmember.StaffHomeActivity;
import com.example.glamourhub.util.TinyDB;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (new TinyDB(SplashActivity.this).getString("USER_TYPE").equals("A")) {
                    Intent intent = new Intent(SplashActivity.this, AdminHomeActivity.class);
                    startActivity(intent);
                    finishAffinity();

                } else if (new TinyDB(SplashActivity.this).getString("USER_TYPE").equals("SM")) {
                    Intent intent = new Intent(SplashActivity.this, StaffHomeActivity.class);
                    startActivity(intent);
                    finishAffinity();

                } else if (new TinyDB(SplashActivity.this).getString("USER_TYPE").equals("C")) {
                    Intent intent = new Intent(SplashActivity.this, CustomerHomeActivity.class);
                    startActivity(intent);
                    finishAffinity();

                } else {
                    Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finishAffinity();
                }

            }
        }, 2000);

    }
}