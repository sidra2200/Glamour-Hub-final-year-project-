package com.example.glamourhub.util;

import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.model.Feedback;
import com.example.glamourhub.model.Services;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.model.Users;

import java.util.ArrayList;
import java.util.List;

public class Constants {


    public static boolean isAccept = false;
    public static int totalCategories = 0;
    public static int assignedCategories = 0;
    public static Users users = null;

    public static Services services = null;

    public static Subservices subservices = null;
    public static List<Subservices> subservicesList = new ArrayList<>();

    public static Bookings bookings = null;

    public static Feedback feedback = null;


}
