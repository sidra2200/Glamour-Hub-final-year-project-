package com.example.glamourhub.customer;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.glamourhub.R;
import com.example.glamourhub.adapter.SubServiceAdapter;
import com.example.glamourhub.admin.ProductDetailActivity;
import com.example.glamourhub.admin.ViewProductActivity;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetSubService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerServiceDetailActivity extends AppCompatActivity {

    ListView SubServicesLV;

    ProgressDialog progressDialog;
    List<Subservices> subServicesList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_service_detail);
        progressDialog = new ProgressDialog(CustomerServiceDetailActivity.this);
        progressDialog.setMessage("please wait..");
        SubServicesLV = findViewById(R.id.SubServicesLV);


      /*  CardView PartyMakeup= findViewById(R.id.PartyMakeup);
        PartyMakeup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                startActivity(new Intent(CustomerServiceDetailActivity.this, CustomerProductDetailActivity.class));
            }
        });*/

        getSubServiceData();

    }

    private void getSubServiceData() {
        progressDialog.show();
        subServicesList.clear();

        RetrofitClient.getClient().create(GetSubService.class).getsubservices().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (data.getInt("fk_service_id") == Constants.services.getService_id()) {
                                    subServicesList.add(new Subservices(
                                            data.getInt("ss_id"),
                                            data.getString("ss_title"),
                                            data.getString("ss_image"),
                                            data.getString("ss_description"),
                                            data.getInt("ss_price"),
                                            data.getString("ss_duration"),
                                            data.getInt("fk_service_id")

                                    ));

                                }

                            }

                            SubServiceAdapter adapter = new SubServiceAdapter(subServicesList,
                                    CustomerServiceDetailActivity.this, new OnItemClick() {
                                @Override
                                public void onClick(int pos) {
                                    Constants.subservices = subServicesList.get(pos);
                                    startActivity(new Intent(getApplicationContext(), CustomerProductDetailActivity.class));
                                    finish();

                                }
                            });
                            SubServicesLV.setAdapter(adapter);


                        } catch (Exception exception) {
                            Toast.makeText(CustomerServiceDetailActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(CustomerServiceDetailActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(CustomerServiceDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }

}