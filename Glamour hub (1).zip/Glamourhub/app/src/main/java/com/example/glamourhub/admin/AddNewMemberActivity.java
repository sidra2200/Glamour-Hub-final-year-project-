package com.example.glamourhub.admin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Services;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetServices;
import com.example.glamourhub.services.InsertStaffMemberService;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddNewMemberActivity extends AppCompatActivity {

    EditText Name, Email, contact, Cnic, Address;
    Button btn_add;
    Spinner specializedFor;
    ProgressDialog progressDialog;
    List<Services> servicesList = new ArrayList<>();
    String selectedSkill;
    List<String> serviceNameList = new ArrayList<>();
    Users users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_member);
        progressDialog = new ProgressDialog(AddNewMemberActivity.this);
        progressDialog.setMessage("please wait..");
        specializedFor = findViewById(R.id.specializedFor);
        Name = findViewById(R.id.Name);
        Email = findViewById(R.id.Email);
        contact = findViewById(R.id.contact);
        Cnic = findViewById(R.id.Cnic);
        Address = findViewById(R.id.Address);
        btn_add = findViewById(R.id.btn_add);


        getServiceData();


        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()) {
                    AddStaffMember();
                }
            }
        });
    }

    public void AddStaffMember() {
        progressDialog.show();
        users = new Users();
        RetrofitClient.getClient().create(InsertStaffMemberService.class).InsertStaffMember(
                Name.getText().toString(),
                Email.getText().toString(),
                Name.getText().toString(),
                Cnic.getText().toString(), contact.getText().toString(), "A", "SM", selectedSkill,
                Address.getText().toString()
        ).enqueue(new Callback<Users>() {
            @Override
            public void onResponse(Call<Users> call, Response<Users> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    users = response.body();
                    if (users.getCode() == 200) {
                        Toast.makeText(AddNewMemberActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), MyStaffActivity.class));
                        finish();
                    } else {
                        Toast.makeText(AddNewMemberActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Users> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(AddNewMemberActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    public boolean validation() {
        boolean isvalid = true;
        if (Name.getText().toString().isEmpty()) {
            Name.setError("fill this field");
            isvalid = false;
        }

        if (Email.getText().toString().isEmpty()) {
            Email.setError("fill this field");
            isvalid = false;
        }
        if (contact.getText().toString().isEmpty()) {
            contact.setError("fill this field");
            isvalid = false;
        }
        if (contact.getText().toString().length() != 11) {
            contact.setError("invalid contact");
            isvalid = false;
        }
        if (Cnic.getText().toString().isEmpty()) {
            Cnic.setError("fill this field");
            isvalid = false;
        }

        if (Cnic.getText().toString().length() != 13) {
            Cnic.setError("invalid cnic");
            isvalid = false;
        }

        if (Address.getText().toString().isEmpty()) {
            Address.setError("fill this field");
            isvalid = false;
        }

        if (specializedFor.toString().isEmpty()) {
            Address.setError("Select Speciality");
            isvalid = false;
        }

        return isvalid;
    }

    private void getServiceData() {
        progressDialog.show();
        servicesList.clear();
        serviceNameList.clear();
        RetrofitClient.getClient().create(GetServices.class).getservices().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {
                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);

                                servicesList.add(new Services(
                                        data.getInt("service_id"),
                                        data.getString("service_title"),
                                        data.getString("service_image"),
                                        data.getString("service_status")
                                ));

                                serviceNameList.add(data.getString("service_title"));

                            }

                            ArrayAdapter<String> adapter = new ArrayAdapter<>(AddNewMemberActivity.this,
                                    android.R.layout.simple_spinner_dropdown_item, serviceNameList);
                            specializedFor.setAdapter(adapter);
                            specializedFor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                    selectedSkill = parent.getItemAtPosition(position).toString();
                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });


                        } catch (Exception exception) {
                            Toast.makeText(AddNewMemberActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(AddNewMemberActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(AddNewMemberActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), MyStaffActivity.class));
        finish();

    }
}