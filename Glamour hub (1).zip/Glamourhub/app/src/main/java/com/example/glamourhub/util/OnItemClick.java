package com.example.glamourhub.util;

public interface OnItemClick {

    void onClick(int pos);

}
