package com.example.glamourhub.services;

import com.example.glamourhub.model.Services;
import com.example.glamourhub.util.EndPoints;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface AddService {

    @Headers("Accept:application/json")
    @Multipart
    @POST(EndPoints.Add_Service_URL)
    Call<Services> AddServices(
            @Part("service_title") RequestBody service_title,
            @Part MultipartBody.Part service_image
    );


}
