package com.example.glamourhub.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Subservices {
    @SerializedName("ss_id")
    @Expose
    private int ss_id;
    @SerializedName("ss_title")
    @Expose
    private String ss_title;
    @SerializedName("ss_image")
    @Expose
    private String ss_image;
    @SerializedName("ss_description")
    @Expose
    private String ss_description;
    @SerializedName("ss_price")
    @Expose
    private int ss_price;
    @SerializedName("ss_duration")
    @Expose
    private String ss_duration;
    @SerializedName("fk_service_id")
    @Expose
    private int fk_service_id;

    @SerializedName("code")
    @Expose
    private int code;

    @SerializedName("error")
    @Expose
    private boolean error;

    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("bd_id")
    @Expose
    private int bd_id;
    @SerializedName("fk_booking_id")
    @Expose
    private int fk_booking_id;
    @SerializedName("fk_subservice_id")
    @Expose
    private int fk_subservice_id;
    @SerializedName("fk_staff_id")
    @Expose
    private int fk_staff_id;
    @SerializedName("service_id")
    @Expose
    private int service_id;
    @SerializedName("service_title")
    @Expose
    private String service_title;

    public Subservices() {
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getSs_id() {
        return ss_id;
    }

    public void setSs_id(int ss_id) {
        this.ss_id = ss_id;
    }

    public String getSs_title() {
        return ss_title;
    }

    public void setSs_title(String ss_title) {
        this.ss_title = ss_title;
    }

    public String getSs_image() {
        return ss_image;
    }

    public void setSs_image(String ss_image) {
        this.ss_image = ss_image;
    }

    public String getSs_description() {
        return ss_description;
    }

    public void setSs_description(String ss_description) {
        this.ss_description = ss_description;
    }

    public int getSs_price() {
        return ss_price;
    }

    public void setSs_price(int ss_price) {
        this.ss_price = ss_price;
    }

    public String getSs_duration() {
        return ss_duration;
    }

    public void setSs_duration(String ss_duration) {
        this.ss_duration = ss_duration;
    }

    public Subservices(int ss_id, String ss_title, String ss_image, String ss_description, int ss_price, String ss_duration, int fk_service_id) {
        this.ss_id = ss_id;
        this.ss_title = ss_title;
        this.ss_image = ss_image;
        this.ss_description = ss_description;
        this.ss_price = ss_price;
        this.ss_duration = ss_duration;
        this.fk_service_id = fk_service_id;

    }

    public Subservices(int bd_id, int fk_booking_id, int fk_subservice_id, int fk_staff_id, int ss_id, String ss_title, String ss_image, int ss_price, int service_id, String service_title) {
        this.bd_id = bd_id;
        this.fk_booking_id = fk_booking_id;
        this.fk_subservice_id = fk_subservice_id;
        this.fk_staff_id = fk_staff_id;
        this.ss_id = ss_id;
        this.ss_title = ss_title;
        this.ss_image = ss_image;
        this.ss_price = ss_price;
        this.service_id = service_id;
        this.service_title = service_title;
    }

    public int getFk_service_id() {
        return fk_service_id;
    }

    public void setFk_service_id(int fk_service_id) {
        this.fk_service_id = fk_service_id;
    }

    public int getBd_id() {
        return bd_id;
    }

    public void setBd_id(int bd_id) {
        this.bd_id = bd_id;
    }

    public int getFk_booking_id() {
        return fk_booking_id;
    }

    public void setFk_booking_id(int fk_booking_id) {
        this.fk_booking_id = fk_booking_id;
    }

    public int getFk_staff_id() {
        return fk_staff_id;
    }

    public void setFk_staff_id(int fk_staff_id) {
        this.fk_staff_id = fk_staff_id;
    }

    public int getFk_subservice_id() {
        return fk_subservice_id;
    }

    public void setFk_subservice_id(int fk_subservice_id) {
        this.fk_subservice_id = fk_subservice_id;
    }

    public int getService_id() {
        return service_id;
    }

    public void setService_id(int service_id) {
        this.service_id = service_id;
    }

    public String getService_title() {
        return service_title;
    }

    public void setService_title(String service_title) {
        this.service_title = service_title;
    }
}
