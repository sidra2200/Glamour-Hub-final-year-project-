package com.example.glamourhub.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.glamourhub.R;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.util.EndPoints;
import com.example.glamourhub.util.OnItemClick;

import java.util.List;

public class SubServiceAdapter extends BaseAdapter {


    List<Subservices> subservicesList;
    Context context;
    OnItemClick onItemClick;
    LayoutInflater inflater;

    public SubServiceAdapter(List<Subservices> subservicesList, Context context, OnItemClick onItemClick) {
        this.context = context;
        this.subservicesList = subservicesList;
        this.onItemClick= onItemClick;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return subservicesList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.item_subservice, parent, false);

        TextView subServiceName = convertView.findViewById(R.id.subServiceName);
        ImageView SubServiceIV = convertView.findViewById(R.id.SubServiceIV);


        subServiceName.setText(subservicesList.get(position).getSs_title());

        Glide.with(context).load(EndPoints.IMAGE_URL + subservicesList.get(position).getSs_image())
                .into(SubServiceIV);


        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.onClick(position);

            }
        });


        return convertView;
    }
}
