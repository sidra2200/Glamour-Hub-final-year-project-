package com.example.glamourhub.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Notification {
    @SerializedName("n_id")
    @Expose
    private int n_id;

    @SerializedName("n_title")
    @Expose
    private String n_title;
    @SerializedName("n_for")
    @Expose
    private String n_for;
    @SerializedName("n_for_id")
    @Expose
    private int n_for_id;
    @SerializedName("n_type")
    @Expose
    private String n_type;
    @SerializedName("n_typeid")
    @Expose
    private int n_typeid;
    @SerializedName("n_createdDateTime")
    @Expose
    private String n_createdDateTime;
    @SerializedName("code")
    @Expose
    private int code;

    @SerializedName("error")
    @Expose
    private boolean error;

    @SerializedName("message")
    @Expose
    private String message;

    public Notification() {
    }

    public int getN_id() {
        return n_id;
    }

    public void setN_id(int n_id) {
        this.n_id = n_id;
    }

    public String getN_title() {
        return n_title;
    }

    public void setN_title(String n_title) {
        this.n_title = n_title;
    }

    public String getN_for() {
        return n_for;
    }

    public void setN_for(String n_for) {
        this.n_for = n_for;
    }

    public int getN_for_id() {
        return n_for_id;
    }

    public void setN_for_id(int n_for_id) {
        this.n_for_id = n_for_id;
    }

    public String getN_type() {
        return n_type;
    }

    public void setN_type(String n_type) {
        this.n_type = n_type;
    }

    public int getN_typeid() {
        return n_typeid;
    }

    public void setN_typeid(int n_typeid) {
        this.n_typeid = n_typeid;
    }

    public String getN_createdDateTime() {
        return n_createdDateTime;
    }

    public void setN_createdDateTime(String n_createdDateTime) {
        this.n_createdDateTime = n_createdDateTime;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Notification(int n_id, String n_title, String n_for, int n_for_id, String n_type, int n_typeid, String n_createdDateTime) {
        this.n_id = n_id;
        this.n_title = n_title;
        this.n_for = n_for;
        this.n_for_id = n_for_id;
        this.n_type = n_type;
        this.n_typeid = n_typeid;
        this.n_createdDateTime = n_createdDateTime;
    }
}
